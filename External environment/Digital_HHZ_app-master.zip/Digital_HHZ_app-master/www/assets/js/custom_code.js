// This functions is used to flip a tile of the sensor dashboard
function flip(panelName){
	$(panelName).toggleClass('flipped');
}


function getHHZNews() {
	var myURL = 'http://85.214.97.142:3000/news/get'
		
	// Get the JSON-object from digital.hhz.de and obtain its values
	try {
		$.getJSON(myURL, function(myJSON) {
				
			// Check if the JSON-object is empty
			if($.isEmptyObject(myJSON) == false) {
					
				// Iterate through JSON array and obtain values of interest
				$.each(myJSON, function() {
					
					var classContainer = "container";
					var idContainer = "container-id-" + this.ID;
					var created = this.created.substring(0,10);
					var message = this.message;
					var URL = this.URL;
					
					// Add a container to the Home-screen to visualize a card
					// When clicking the container, a URL is opened
					var divContainer = document.createElement("div");
					divContainer.setAttribute("class", classContainer);
					divContainer.setAttribute("id", idContainer);
					document.getElementById("home-wrapper").appendChild(divContainer);
					//divContainer.onclick = function(){window.location.href=URL;};
					divContainer.onclick = function(){cordova.InAppBrowser.open(URL, '_self', 'location=yes');};
					
					// Add a header to the container (date when the news was created)
					var divHeader = document.createElement("div");
					divHeader.innerHTML = created;
					divHeader.style.fontWeight = 'bold';
					document.getElementById(idContainer).appendChild(divHeader);
					
					// Add a content to the header (actual content of the news)
					var divContent = document.createElement("div");
					divContent.innerHTML = message;
					document.getElementById(idContainer).appendChild(divContent);
				});
				
			} else {
				// Print out error message because the JSON-object is empty
				alert("ERROR: Data not available.");
			}
				
		});					
	} catch (e) {
		// Print out error message because obtaining the JSON-object failed
		alert("ERROR: Data could not be obtained. Please try again later!");
	}
}


function getSensorDataForRoom(roomNumber) {
	var temperature = 'sensor.' + roomNumber + '_temp_a';
	var humidity = 'sensor.' + roomNumber + '_hum_a';
	var co2 = 'sensor.' + roomNumber + '_co2_a';
	var light = 'sensor.' + roomNumber + '_light_a';
	
	getSensorData(temperature, 'Temp');
	getSensorData(humidity, 'Hum');
	getSensorData(co2, 'CO2');
	getSensorData(light, 'Light');
}


function getSensorData(entityID, divID){
	var myURL = 'http://digital.hhz.de:3000/data/get?id=' + entityID
	var sensorType = '';
	var updateFrequency = '10 Minuten';
	
	if (divID == 'Temp') {
		sensorType = 'DHT-11';
	} else if (divID == 'Hum') {
		sensorType = 'DHT-11';
	} else if (divID == 'CO2') {
		sensorType = 'REHAU Air Quality';
	} else if (divID == 'Light') {
		sensorType = 'BH-1750';
	}
	
	// Get the JSON-object from digital.hhz.de and obtain its values
	try {
		$.getJSON(myURL, function(myJSON) {
			
			// Check if the JSON-object is empty
			if($.isEmptyObject(myJSON) == false) {
				
				// Iterate through JSON array and obtain values of interest
				
				$.each(myJSON, function() {
					$("#value" + divID).text(this.state);
					$("#lastUpdated" + divID).text(this.last_updated);
					$("#sensorType" + divID).text(sensorType);
					$("#updateFrequency" + divID).text(updateFrequency);
				});
			
			} else {
				// Print out error message because the JSON-object is empty
				alert("ERROR: Data not available.");
			}
			
		});					
	} catch (e) {
		// Print out error message because obtaining the JSON-object failed
		alert("ERROR: Data could not be obtained. Please try again later!");
	}
}