import { Component, ViewChild } from '@angular/core';
import { Platform, MenuController, Nav } from 'ionic-angular';
import { StatusBar, Splashscreen } from 'ionic-native';
import { InAppBrowser, InAppBrowserOptions } from "@ionic-native/in-app-browser";

import { TabsPage } from '../pages/tabs/tabs';
import { Sensor } from '../pages/sensor/sensor';
import { Chat} from '../pages/chat/chat';
import { Linksammlung } from '../pages/linksammlung/linksammlung';


export interface PageInterface {
  title: string;
  component: any;
  icon: string;
  index?: number;
}

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  // set our app's pages
  appPages: PageInterface[] = [
    { title: 'Home', component: TabsPage, index: 0, icon: 'home' },
    { title: 'Kalendar', component: TabsPage, index: 2, icon: 'calendar' },
    { title: 'Chat', component: TabsPage, index: 1, icon: 'chatboxes' },
    { title: 'Sensorumgebung', component: Sensor, icon: 'pulse' },
    { title: 'Linksammlung', component: Linksammlung, icon: 'browsers' }
   ];

  rootPage = TabsPage;

  constructor(platform: Platform, public menu: MenuController, private inAppBrowser: InAppBrowser) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      StatusBar.styleDefault();
      Splashscreen.hide();
    });    
  }

  openPage(page: PageInterface) {
    // the nav component was found using @ViewChild(Nav)
    // reset the nav to remove previous pages and only have this page
    // we wouldn't want the back button to show in this scenario

    this.menu.close();

    if (page.index) {
	  
	  // If the user clicked on "Chat", Telegram will open without showing a page in the app    
      if(page.index == 1) {
     	
	    const options: InAppBrowserOptions = {
		  location:'yes',
		  presentationstyle:'pagesheet'
		}
		  
      	const browser = this.inAppBrowser.create('https://t.me/DigitalHHZ', '_system', options);
      
      // If the user clicked on anything else but "Chat", the corresponding page will show up in the app 	
      } else {
        
        this.nav.setRoot(page.component, { tabIndex: page.index });
      
      }
      
    } else {
      this.nav.setRoot(page.component).catch(() => {
        console.log("Didn't set nav root");
      });
    }


  }

}
