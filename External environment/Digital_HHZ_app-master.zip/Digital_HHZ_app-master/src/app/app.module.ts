import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { InAppBrowser } from '@ionic-native/in-app-browser';

import { MyApp } from './app.component';
import { Calendar } from '../pages/calendar/calendar';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import { Chat} from '../pages/chat/chat';
import { Sensor } from '../pages/sensor/sensor';
import { Eg120 } from '../pages/eg120/eg120';
import { Eg125 } from '../pages/eg125/eg125';
import { Eg126 } from '../pages/eg126/eg126';
import { Linksammlung } from '../pages/linksammlung/linksammlung';



@NgModule({
  declarations: [
    MyApp,
    Calendar,
    HomePage,
    TabsPage,
    Chat,
    Sensor,
    Eg120,
    Eg125,
    Eg126,
    Linksammlung
  ],
  imports: [
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    Calendar,
    HomePage,
    TabsPage,
    Sensor,
    Chat,
    Eg120,
    Eg125,
    Eg126,
    Linksammlung
  ],
  providers: [
    {provide: ErrorHandler, useClass: IonicErrorHandler},
	InAppBrowser
  ]
})
export class AppModule {}
