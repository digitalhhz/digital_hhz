import { Component } from '@angular/core';
import { InAppBrowser, InAppBrowserOptions } from "@ionic-native/in-app-browser";

//import { NavController } from 'ionic-angular';

declare function getHHZNews();

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

    constructor() {

    }

    ionViewDidLoad() {
		// EDIT BY MANH ON FEB 24, 2018: Obtain and display the HHZ news in the Home-screen    
	    getHHZNews(); // Function is located in ../../assets/js/custom_code.js
    }

}
