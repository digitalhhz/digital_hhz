import { Component } from '@angular/core';

//import { NavController } from 'ionic-angular';

declare function getSensorDataForRoom(roomNumber);

@Component({
	  selector: 'page-eg126',
	  templateUrl: 'eg126.html'
})
export class Eg126 {
		
	constructor() {
	
	}
	
	ionViewDidLoad() {
		getSensorDataForRoom('126_2');
	}
}
