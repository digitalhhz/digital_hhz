import { Component, OnInit } from '@angular/core';
import { InAppBrowser, InAppBrowserOptions } from "@ionic-native/in-app-browser";

//import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-linksammlung',
  templateUrl: 'linksammlung.html'
})
export class Linksammlung {

  url: string;
  
  constructor(private inAppBrowser: InAppBrowser) {
	
  }
  
  // Function which opens a webpage
  openWebpage(url: string) {
	const options: InAppBrowserOptions = {
	  location:'yes',
	  presentationstyle:'pagesheet'
	}
	const browser = this.inAppBrowser.create(url, '_system', options);
  }

}
