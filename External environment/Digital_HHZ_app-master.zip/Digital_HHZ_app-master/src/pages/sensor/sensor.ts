import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Eg120 } from '../eg120/eg120';
import { Eg125 } from '../eg125/eg125';
import { Eg126 } from '../eg126/eg126';

@Component({
	  selector: 'page-sensor',
	  templateUrl: 'sensor.html'
})
export class Sensor {
	
	rooms: any;
	
	constructor(public navCtrl: NavController) {
		this.rooms = [
			{name: 'EG-120', description: 'Großraumbüro', icon: 'assets/img/eg120.png', page: Eg120},
			{name: 'EG-125', description: 'Vorlesungsraum', icon: 'assets/img/eg125.png', page: Eg125},
			{name: 'EG-126', description: 'Kaffeeküche', icon: 'assets/img/eg126.png', page: Eg126}	
		];	
	}
	
	goToPage(page: any) {
		this.navCtrl.push(page);
	}
}
