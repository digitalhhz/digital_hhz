import { Component } from '@angular/core';
import { NavParams, NavController } from 'ionic-angular';
import { InAppBrowser, InAppBrowserOptions } from "@ionic-native/in-app-browser";

import { HomePage } from '../home/home';
import { Chat } from '../chat/chat';
import { Calendar } from '../calendar/calendar';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {
  // this tells the tabs component which Pages
  // should be each tab's root Page
  tab1Root: any = HomePage;
  tab2Root: any = Chat;
  tab3Root: any = Calendar;
  mySelectedIndex: number;
  
  constructor(navParams: NavParams, private inAppBrowser: InAppBrowser, public navCtrl: NavController) {
    this.mySelectedIndex = navParams.data.tabIndex || 0;
  }
  
  openTelegram() {
  	
  	// Open Telegram in browser
	const options: InAppBrowserOptions = {
      location:'yes',
	  presentationstyle:'pagesheet'
	}
		  
    const browser = this.inAppBrowser.create('https://t.me/DigitalHHZ', '_system', options);

  	// Show the Calendar
	this.navCtrl.setRoot(TabsPage, { tabIndex: 2 });
	
  }
}
