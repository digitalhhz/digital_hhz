import { Component } from '@angular/core';

//import { NavController } from 'ionic-angular';

declare function getSensorDataForRoom(roomNumber);

@Component({
	  selector: 'page-eg125',
	  templateUrl: 'eg125.html'
})
export class Eg125 {
		
	constructor() {

	}
	
	ionViewDidLoad() {
		getSensorDataForRoom('125');
	}
}
