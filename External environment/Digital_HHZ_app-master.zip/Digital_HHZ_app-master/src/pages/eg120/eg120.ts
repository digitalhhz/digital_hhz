import { Component } from '@angular/core';

//import { NavController } from 'ionic-angular';

declare function getSensorDataForRoom(roomNumber);

@Component({
	  selector: 'page-eg120',
	  templateUrl: 'eg120.html'
})
export class Eg120 {
	constructor() {
	}
	
	ionViewDidLoad() {
		getSensorDataForRoom('120');
	}
}
